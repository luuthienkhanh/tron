/****************************************************************************
 * Product Name : HI7700/4
 *   Copyright (c) 2000(2005) Renesas Technology Corp.
 *   and Renesas Solutions Corp. All rights reserved.
 * File Name : shdsp.h
 * File Version : 20050512
 ****************************************************************************/
/****************************************************************************/
/*          Constant definition                                             */
/****************************************************************************/
#define DSP_BIT    0x00001000UL         /* DSP bit (for SH-DSP)             */
/****************************************************************************/
/*              DSP save area                                               */
/****************************************************************************/
#pragma pack 4

typedef struct {                        /* DSP save area                    */
    UW          a0;                     /* A0  register                     */
    UW          a1;                     /* A1  register                     */
    UW          a0g;                    /* A0G register                     */
    UW          a1g;                    /* A1G register                     */
    UW          m0;                     /* M0  register                     */
    UW          m1;                     /* M1  register                     */
    UW          x0;                     /* X0  register                     */
    UW          dsr;                    /* DSR register                     */
    UW          x1;                     /* X1  register                     */
    UW          rs;                     /* RS  register                     */
    UW          y0;                     /* Y0  register                     */
    UW          re;                     /* RE  register                     */
    UW          y1;                     /* Y1  register                     */
    UW          mod;                    /* MOD register                     */
} T_DSP;

#pragma unpack
/****************************************************************************/
/*              macro definition                                            */
/****************************************************************************/
/*------------------------ save DSP registers ------------------------------*/
#pragma inline_asm(IniDSP)
static  void    IniDSP(T_DSP *pk_save)
{
SIZE_T_DSP          .assign    4*14            ; sizeof(T_DSP)

    add     #SIZE_T_DSP,r4          ; pk_save += sizeof(T_DSP)

    stc.l   mod,@-r4                ; save DSP registers
    movs.l  y1,@-r4
    stc.l   re,@-r4
    movs.l  y0,@-r4
    stc.l   rs,@-r4
    movs.l  x1,@-r4
    sts.l   dsr,@-r4
    movs.l  x0,@-r4
    movs.l  m1,@-r4
    movs.l  m0,@-r4
    movs.l  a1g,@-r4
    movs.l  a0g,@-r4
    movs.l  a1,@-r4
    movs.l  a0,@-r4
}
/*---------------------- restore dsp registers -----------------------------*/
#pragma inline_asm(EndDSP)
static  void    EndDSP(T_DSP *pk_save)
{
    movs.l  @r4+,a0                 ; restore DSP registers
    movs.l  @r4+,a1
    movs.l  @r4+,a0g
    movs.l  @r4+,a1g
    movs.l  @r4+,m0
    movs.l  @r4+,m1
    movs.l  @r4+,x0
    lds.l   @r4+,dsr
    movs.l  @r4+,x1
    ldc.l   @r4+,rs
    movs.l  @r4+,y0
    ldc.l   @r4+,re
    movs.l  @r4+,y1
    ldc.l   @r4+,mod
}
