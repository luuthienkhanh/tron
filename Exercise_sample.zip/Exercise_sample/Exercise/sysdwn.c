/****************************************************************************
 * System down routine
 ****************************************************************************/

/****************************************************************************
 * Section definition
 ****************************************************************************/
#pragma section _hisysdwn

/****************************************************************************
 * Include
 ****************************************************************************/
#include <machine.h>	// [Provided by C-compiler]
#include "kernel.h"		// [Provided by HI7700/4] HI7700/4 header file

/****************************************************************************
 * Definitions
 ****************************************************************************/
#define MD_BIT 0x40000000UL             /* SR.MD bit                        */

/****************************************************************************
 * Prototype definition
 ****************************************************************************/
extern void _kernel_sysdwn(W, ER, VW, VW);

/****************************************************************************
 * NAME : void _kernel_sysdwn(W type, ER ercd, VW inf1, VW inf2)
 * FUNC : System down routine
 *        This routine must not return.
 *   The name "_kernel_sysdwn" must not be changed.
 ****************************************************************************/
void    _kernel_sysdwn(type, ercd, inf1, inf2)
W type; /*system down type */
                 /* type >=  1 : system down of user program                */
                 /* type ==  0 : initial information error                  */
                 /* type == -1 : context error of ext_tsk                   */
                 /* type == -2 : context error of exd_tsk                   */
                 /* type == -16: undefined interrupt/exception              */
ER ercd; /* error code  */
                 /* type >=  0 : error code of user program                 */
                 /* type ==  0 : error code of initial information          */
                 /* type == -1 : error code of ext_tsk                      */
                 /* type == -2 : error code of exd_tsk                      */
                 /* type == -16: interrupt vector number                    */
VW inf1; /* information-1  */
                 /* type >=  0 : information of user program                */
                 /* type ==  0 : indicator of initial information error     */
                 /* type == -1 : address of ext_tsk call                    */
                 /* type == -2 : address of exd_tsk call                    */
                 /* type == -16: address of interrupt occurrence            */
VW inf2; /* information-2  */
                 /* type >=  0 : information of user program                */
                 /* type ==  0 : number of error initial information        */
                 /* type == -16: SR of interrupt occurrence                 */
{
	/*** Mask all interrupt ***/
    set_cr((INT)(MD_BIT | (SR_IMS15 << 4)));

    /*** Endless loop ***/
    while(1) {
    
	}
}
